function printPattern(){

    for( var i=0; i<4; i++){
        for (var j =0; j<=i;j++){
            document.write(" * ");
        }
        document.write('<br/>');
    }
}