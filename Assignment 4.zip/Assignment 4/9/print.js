function printText(){
    
    var txt = ['J','Ja','Jav','Java','Javas','Javasc','Javasc','Javascr','Javascri','Javascrip','Javascript'];

    for (var x of txt) {
        document.write(x + "<br >");
    }
   
}